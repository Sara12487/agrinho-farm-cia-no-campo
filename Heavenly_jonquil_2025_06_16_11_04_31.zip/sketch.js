let carro;
let farmacia;
let nuvens = [];
let passarinhos = [];
let arvores = [];
let mensagem = false;

function setup() {
  createCanvas(800, 600);
  carro = new Carro();
  farmacia = new Farmacia();
  
  // Criando algumas nuvens
  for (let i = 0; i < 5; i++) {
    nuvens.push(new Nuvem(random(width), random(100, 200)));
  }

  // Criando alguns passarinhos
  for (let i = 0; i < 3; i++) {
    passarinhos.push(new Passarinho(random(width), random(50, 150)));
  }

  // Criando algumas árvores
  for (let i = 0; i < 6; i++) {
    arvores.push(new Arvore(random(50, 750), random(400, 550)));
  }
}

function draw() {
  // Céu
  background(135, 206, 235);
  
  // Desenho das nuvens
  for (let nuvem of nuvens) {
    nuvem.mover();
    nuvem.mostrar();
  }

  // Desenho dos passarinhos
  for (let passarinho of passarinhos) {
    passarinho.mover();
    passarinho.mostrar();
  }

  // Desenho das árvores
  for (let arvore of arvores) {
    arvore.mostrar();
  }

  // Estrada
  drawEstrada();

  // Mostrar a farmácia
  farmacia.mostrar();

  // Mostrar o carro e mover
  carro.mover();
  carro.mostrar();

  // Se o carro chegou na farmácia, mostrar a mensagem
  if (carro.x >= farmacia.x - 60 && !mensagem) {
    mensagem = true;
  }
  
  if (mensagem) {
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Chegou à farmácia!", width / 2, height / 2);
  }
}

// Função para desenhar a estrada com aspecto rural
function drawEstrada() {
  fill(150, 75, 0); // Cor da estrada (marrom)
  beginShape();
  vertex(0, height - 120);
  vertex(width, height - 120);
  vertex(width, height);
  vertex(0, height);
  endShape(CLOSE);
  
  // Linhas da estrada (bem simples)
  stroke(255);
  strokeWeight(4);
  for (let i = 0; i < width; i += 60) {
    line(i, height - 60, i + 30, height - 60);
  }
}

// Classe do Carro
class Carro {
  constructor() {
    this.x = -100;
    this.y = height - 80;
    this.velocidade = 2;
    this.largura = 80;
    this.altura = 40;
  }

  mover() {
    if (this.x < farmacia.x - 60) {
      this.x += this.velocidade;
    }
  }

  mostrar() {
    fill(255, 0, 0);
    noStroke();
    rect(this.x, this.y, this.largura, this.altura, 10);  // corpo do carro

    // Rodas
    fill(0);
    ellipse(this.x + 20, this.y + this.altura, 20, 20);
    ellipse(this.x + this.largura - 20, this.y + this.altura, 20, 20);
  }
}

// Classe da Farmácia (agora com cruz vermelha e mais detalhes)
class Farmacia {
  constructor() {
    this.x = 600;
    this.y = height - 160;
    this.largura = 120;
    this.altura = 100;
  }

  mostrar() {
    // Corpo da farmácia (estruturado para um estilo rural)
    fill(255, 255, 255); // Cor da parede
    rect(this.x, this.y, this.largura, this.altura);

    // Telhado de madeira simples (mais funcional)
    fill(139, 69, 19); // Cor de telhado rústico
    triangle(this.x, this.y, this.x + this.largura, this.y, this.x + this.largura / 2, this.y - 30);

    // Placa da farmácia (agora mais visível)
    fill(255, 0, 0);
    textSize(16);
    textAlign(CENTER, CENTER);
    text("Farmácia", this.x + this.largura / 2, this.y + 20);

    // Cruz vermelha (símbolo clássico)
    stroke(0);
    strokeWeight(3);
    fill(255, 0, 0);  // Cruz vermelha
    rect(this.x + this.largura / 2 - 15, this.y + this.altura / 2 - 15, 30, 50);  // barra vertical
    rect(this.x + this.largura / 2 - 15, this.y + this.altura / 2 - 15, 50, 30);  // barra horizontal

    // Porta (rústica, com detalhes)
    fill(139, 69, 19);
    rect(this.x + 45, this.y + 50, 30, 50);

    // Detalhes no telhado
    fill(255);
    stroke(0);
    strokeWeight(2);
    line(this.x + 10, this.y - 20, this.x + 110, this.y - 20);  // Linha simples no telhado

    // Sombra para dar mais profundidade
    fill(0, 0, 0, 50);
    beginShape();
    vertex(this.x + 10, this.y + this.altura);
    vertex(this.x + this.largura - 10, this.y + this.altura);
    vertex(this.x + this.largura - 10, this.y + this.altura + 10);
    vertex(this.x + 10, this.y + this.altura + 10);
    endShape(CLOSE);
  }
}

// Classe da Nuvem
class Nuvem {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = 0.5;
  }

  mover() {
    this.x += this.velocidade;
    if (this.x > width) {
      this.x = -200;
    }
  }

  mostrar() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, 100, 60);
    ellipse(this.x + 50, this.y - 20, 100, 60);
    ellipse(this.x - 50, this.y - 20, 100, 60);
  }
}

// Classe do Passarinho
class Passarinho {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.velocidade = random(1, 3);
    this.direcao = random([-1, 1]);  // Para voar para a esquerda ou direita
    this.tamanho = random(15, 30);
    this.cor = color(random(255), random(255), random(255)); // Cor aleatória para cada passarinho
  }

  mover() {
    this.x += this.velocidade * this.direcao;
    if (this.x > width + 50) {
      this.x = -50;
    } else if (this.x < -50) {
      this.x = width + 50;
    }
    this.y += sin(frameCount * 0.05) * 2; // Movimento suave para cima e para baixo
  }

  mostrar() {
    fill(this.cor);
    noStroke();
    // Corpo do passarinho (forma oval)
    ellipse(this.x, this.y, this.tamanho, this.tamanho / 1.5);

    // Asinhas
    fill(255, 255, 255);
    triangle(this.x - this.tamanho / 2, this.y - this.tamanho / 4, 
             this.x, this.y - this.tamanho / 1.5, 
             this.x + this.tamanho / 2, this.y - this.tamanho / 4);

    // Cauda
    line(this.x - this.tamanho / 4, this.y + this.tamanho / 3, 
         this.x + this.tamanho / 4, this.y + this.tamanho / 3);
  }
}

// Classe da Árvore
class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  mostrar() {
    // Tronco
    fill(139, 69, 19);
    rect(this.x, this.y, 20, 60);

    // Folhagem
    fill(34, 139, 34);
    ellipse(this.x - 20, this.y - 20, 60, 60);
    ellipse(this.x + 10, this.y - 20, 60, 60);
    ellipse(this.x + 40, this.y - 20, 60, 60);
  }
}
